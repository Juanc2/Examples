<?php
$conexion = pg_connect("host=localhost user=postgres password=1236245213 dbname=Curso_php port=5432")

?>