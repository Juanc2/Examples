<?php session_start(); ?>
<?php include('encabezado.php');?>
<?php include('base_datos/abrir_conexion_mysql.php');?>

<?php 
if(isset($_POST['guardar']))
{
  if($_POST['materia']=="" || $_POST['alumno']=="" || $_POST['nota']=="")
  {
     echo "asegurese de llenar los campos obligatorios";
  }
  else
  {
    $cant=0;
    $sql="SELECT Codigo from persona_materia where Codigo='".$_POST['materia']."' and Cedula='".$_POST['alumno']."'";
	$resultado = mysql_query($sql,$conexion) or die (mysql_error());
	$cant = mysql_num_rows($resultado);
	if($cant > 0)
	    echo "Existe nota para este alumno en esta materia";
	 else
	 {
	   echo $sql="insert into persona_materia (Codigo,Cedula,Nota) values ('".$_POST['materia']."','".$_POST['alumno']."','".$_POST['nota']."')";
	   $resultado = mysql_query($sql,$conexion) or die (mysql_error());
	   if($resultado==true)
	   {
	   echo 'Registro exitoso';
	   echo "<script languaje='javascript'>location.href='adm_notas.php'</script>";
	   } 
	   else
	   echo 'Error al insertar datos';
	 }
  } 
}
?>

<table width="100%" background="Imagenes/background.jpg" align="center" border="1" bordercolor="#CCCCCC" background="Imagenes/background.jpg" cellpadding="0" cellspacing="0" height="100%">

    <?php include('banner.php');?>
  <tr>
    <?php include('menu.php'); ?>
    <td  valign="top" height="150" >
	<form name="form_materia" action="" method="post" enctype="application/x-www-form-urlencoded">
	  <table width="95%" align="center" border="0" cellpadding="0" cellspacing="0">
	  <tr>
	    <td width="12%">Alumno:</td>
		<td width="88%">
		<select name="alumno">
		 <option value="">Seleccione</option>
		 <?php
		 
		 $sql_prof="select Cedula,Nombre,Apellido from persona where Tipo='alumno' order by Nombre,Apellido,Cedula asc" ;
		 $resultato_prof= mysql_query($sql_prof,$conexion) or die (mysql_error());
		 while($prof = mysql_fetch_array($resultato_prof))
		 {
		 
		 ?>
		 <option value="<?php echo $prof['Cedula']?>"><?php echo $prof['Nombre'].' '.$prof['Apellido']?></option>
		 <?php 
		 }
		 ?>
	    </select>		</td>
	  </tr>
	  <tr>
	  <td>Materia:</td>
	  <td>
	  <select name="materia">
		 <option value="0">Seleccione</option>
		 <?php
		 
		 $sql_prof="select Nombre,Codigo from materia order by Nombre asc" ;
		 $resultato_prof= mysql_query($sql_prof,$conexion) or die (mysql_error());
		 while($prof = mysql_fetch_array($resultato_prof))
		 {
		 
		 ?>
		 <option value="<?php echo $prof['Codigo']?>"><?php echo $prof['Nombre'];?></option>
		 <?php 
		 }
		 ?>
	    </select>		</td>
	  </tr>
	  <tr>
	  <td>Nota:</td>
	  <td><input type="text" name="nota" size"5"></td>
	  </tr>
	   <tr>
	    <td colspan="2">
		<input type="submit" name="guardar" value="Agregar" />&nbsp;&nbsp;&nbsp;
		<input type="reset" name="limpiar" value="Limpiar" /></td>
	  </tr>
	  <tr>
	    <td>
		<a href="adm_notas.php">Volver</a>		</td>
	  </tr>
	</table>
  </form>
	</td>
	  
  </tr>
  <?php include('pie_pagina.php');?>
</table>
 <?php include('Fin_encabezado.php');?>