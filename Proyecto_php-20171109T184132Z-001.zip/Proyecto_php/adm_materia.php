<?php session_start(); ?>
<?php include('encabezado.php');?>



<table width="100%" align="center" height="100%" border="1" bordercolor="#CCCCCC" cellpadding="0" cellspacing="0" height="400" background="Imagenes/background.jpg">

    <?php include('banner.php');?>
  <tr>
    <?php include('menu.php'); ?>
    <td  valign="top" height="150" >
	<br />
    <br />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
       <a href="agregar_materia.php">Agregar materia</a>
	 
	   <table width="95%" border="1" cellpadding="0" cellspacing="0" >
	    
	     <tr>
		   <th>editar/borrar</th>
		   <th>C&oacute;digo</th>
		   <th>Nombre</th>
		   <th>Descripcion</th>
		   <th>Profesor</th>
		 </tr>
		 <?php
		 include("base_datos/abrir_conexion_mysql.php");
		 $sql= "SELECT m.*,p.Nombre as profesor,p.Apellido FROM materia m inner join persona p using (Cedula) ORDER BY Codigo ASC";
		 $resultado = mysql_query($sql,$conexion) or die (mysql_error());
		 while($filas = mysql_fetch_array($resultado))
		 {
		 ?>
		 <tr>
		   <td align="center"><a href="editar_materia.php?id=<?php echo $filas['Codigo']?>"><img src="Imagenes/editar.png" width="17" height="17" title="editar" /></a>&nbsp; <a href="eliminar_materia.php?id=<?php echo $filas['Codigo']?>"><img src="Imagenes/borrar.png" width="17" height="17" title="borrar" /></a>  
		   </td>
		   <td align="center"><?php echo $filas['Codigo'] ?></td>
		   <td align="center"><?php echo $filas['Nombre'] ?></td>
		   <td align="center"><?php echo $filas['Descripcion'] ?></td>
		   <td align="center"><?php echo $filas['profesor'] ?></td>
		  </tr>
		  <?php
		  }
		  ?>
		  </table>
	</td>
	  
  </tr>
  <?php include('pie_pagina.php');?>
</table>
 <?php include('Fin_encabezado.php');?>