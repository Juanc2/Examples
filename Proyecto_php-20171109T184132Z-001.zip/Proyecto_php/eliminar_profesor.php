<?php
session_start();
include('base_datos/abrir_conexion_mysql.php');
if(isset($_GET['id']))
{
  $sql = "delete from persona where Cedula = '".$_GET['id']."'";
  $resultado = mysql_query($sql,$conexion) or die(mysql_error());
  include('base_datos/cerrar_mysql.php');
  ?>
  <script language="javascript">location.href='adm_profesor.php'</script>
<?php
}
?>