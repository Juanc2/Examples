<?php session_start(); ?>
<?php include('encabezado.php');?>
<?php include('base_datos/abrir_conexion_mysql.php');?>

<?php 
if(isset($_GET['id']))
{
   $sql="select * from materia where Codigo='".$_GET['id']."'";
   $resultado= mysql_query($sql,$conexion) or die (mysql_error());
   $filas=mysql_fetch_array($resultado);
   
   $aux_co = $filas['Codigo'];
   $aux_nombre = $filas['Nombre'];
   $aux_descripcion = $filas['Descripcion'];
   $aux_prof = $filas['Cedula'];
   }

if(isset($_POST['guardar']))
{
 if($_POST['codigo']=="" || $_POST['nombre']=="" || $_POST['profesor']=="")
 {
      echo 'Asegurese de llenar los campos clave';
 }
 else 
 {
 if($_POST['codigo']==$_POST['const_id'])
	{
		$sql = "UPDATE materia SET 
			Cedula = '".$_POST['profesor']."',
			Nombre = '".$_POST['nombre']."',
			Descripcion = '".$_POST['descripcion']."'
			WHERE Codigo = '".$_POST['const_id']."'";
			
		$result = mysql_query($sql,$conexion) or die (mysql_error());
		if($result==true)
		{
			echo 'Registro modificado satisfactoriamente';
		?>
				<script language="javascript">location.href='adm_materia.php'</script>
<?php		
		}
	}
	else
	{
		$sql="SELECT Codigo FROM materia WHERE Codigo='".$_POST['codigo']."'";
		$resultado = mysql_query($sql,$conexion) or die (mysql_error());
		$cant = mysql_num_rows($resultado);
		if($cant > 0)
			echo "Existe una materia con ese codigo";
		else
		{
			$sql = "UPDATE materia SET 
			Codigo ='".$_POST['codigo']."',
			Nombre = '".$_POST['nombre']."',
			Descripcion = '".$_POST['descripcion']."',
			Cedula = '".$_POST['profesor']."'
			WHERE Codigo = '".$const_id."'";
			
			$result = mysql_query($sql,$conexion) or die (mysql_error());
			if($result==true)
			{
				echo 'Registro modificado satisfactoriamente';
				?>
				<script language="javascript">location.href='adm_materia.php'</script>
<?php	
			}
		}
	}
}
}

if(isset($_POST['codigo'])) $aux_co = $_POST['codigo'];
if(isset($_POST['nombre'])) $aux_nombre = $_POST['nombre'];
if(isset($_POST['descripcion'])) $aux_descripcion = $_POST['descripcion'];
if(isset($_POST['profesor'])) $aux_prof = $_POST['profesor'];
?>

<table width="100%" background="Imagenes/background.jpg" align="center" border="1" bordercolor="#CCCCCC" cellpadding="0" cellspacing="0" height="100%">

    <?php include('banner.php');?>
  <tr>
    <?php include('menu.php'); ?>
    <td  valign="top" height="150" >
	<form name="form_materia" action="" method="post" enctype="application/x-www-form-urlencoded">
	<input type="hidden" name="const_id" value="<?php echo $aux_co ?>" />
	  <table width="95%" align="center" border="0" cellpadding="0" cellspacing="0">
	  <tr>
	    <td>C&oacute;digo</td>
		<td><input type="text" name="codigo" value="<?php echo $aux_co ?>" size="30" maxlength="10"/>*</td>
	  </tr>
	   <tr>
	    <td>Nombre:</td>
		<td><input type="text" name="nombre" value="<?php echo $aux_nombre ?>" size="30"/>*</td>
	  </tr>
	  <tr>
	    <td>Descripci&oacute;n:</td>
		<td><textarea name="descripcion" rows="5" cols="15" ><?php echo $aux_descripcion ?></textarea></td>
	  </tr>
	  <tr>
	    <td>Profesor:</td>
		<td>
		
		<select name="profesor">
		 <option value="">Seleccione</option>
		 <?php
		 
		 $sql_prof="select Cedula,Nombre,Apellido from persona where Tipo='profesor' order by Nombre,Apellido" ;
		 $resultato_prof= mysql_query($sql_prof,$conexion) or die (mysql_error());
		 while($prof = mysql_fetch_array($resultato_prof))
		 {
		 
		 ?>
		 <option value="<?php echo $prof['Cedula']?>"<?php if($aux_prof==$prof['Cedula']) echo 'selected="selected"' ?>><?php echo $prof['Nombre'].' '.$prof['Apellido']?></option>
		 <?php
		 }
		 ?>
	    </select>
		</td>
	  </tr>
	   <tr>
	    <td>
		<input type="submit" name="guardar" value="Listo" />&nbsp;&nbsp;&nbsp;
		<input type="reset" name="limpiar" value="Borrar" />
		
		</td>
	  </tr>
	  <tr>
	    <td>
		<a href="adm_materia.php">Volver</a>
		
		</td>
	  </tr>
	  
	</table>
  </form>
	</td>
	  
  </tr>
  <?php include('pie_pagina.php');?>
</table>
 <?php include('Fin_encabezado.php');?>