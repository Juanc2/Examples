<?php
	if (!isset($_SESSION['started']) && !$_SESSION['started'])
	{
		session_start();
		$_SESSION['started'] = true;
	}
	
	$redir_error = "acceso.php";
	$redir_admin = "administracion.php";
    $redir_profesor = "adm_profesor.php";
	
	if (isset ($_POST['usuario']) && isset ($_POST['clave']))
	{
		$_POST['usuario'] = strtolower($_POST['usuario']);//strtolower : pasa los caracteres de mayuscula a minuscula
		$_POST['clave'] = strtolower($_POST['clave']);
		$user_login = stripslashes($_POST['usuario']);// eliminamos barras invertidas y dobles en sencillas
		$user_password = md5($_POST['clave']);// encriptamos el password en formato md5 irreversible. //OJOOOOOO
	}
	else
	{
	
			// redireccion hacia acceso,
			header ("Location: $redir_error");
			exit;
		}
	
	
	// cargar datos conexion base de datos
	include("Base_datos/abrir_conexion_mysql.php");
	
	// consulta base de datos para validar usuario
	$sql = "SELECT * FROM usuario WHERE Login = '".$user_login."'";
	$recordset_user = mysql_query ($sql,$conexion) or die (mysql_error());
	$count_user = mysql_num_rows ($recordset_user);

	$error = 0;
	// verificacion si el login recibido es un usuario
	if ($count_user != 0)
	{
		// almacenamos datos del usuario en un array
		$user_register = mysql_fetch_array($recordset_user);
		
		// comprobacion del login recibido
		if ($user_login != $user_register['Login'])
		{
			// redireccion hacia acceso, con salida de error 1 (nombre usuario incorrecto)
			$error = 1;
		}

		// comprobacion de la clave recibida
		if ($user_password != $user_register['Clave'])
		{
			// redireccion hacia acceso, con salida de error 2 (clave usuario incorrecta)
			$error = 2;
		}
	}
	else 
	{
		// redireccion hacia acceso, con salida de error 3 (usuario no encontrado)
		$error = 3;
	}	
	
	// cierre de conexion con la base de datos
	include("Base_datos/Cerrar_mysql.php");
	if ($error > 0) 
	{
		header ("Location: acceso.php?error={$error}");
		exit;
	}
	else
	{
		// en este punto, el usuario ya esta validado
		// guardamos los datos del usuario en una session
		 $_SESSION['user_login'] = $user_login;
		 $_SESSION['user_password'] = $user_password;
		 $_SESSION['nivel'] = $user_register['Nivel'];
		
		switch($_SESSION['nivel'])
		{
		   case "administrador";
			 header ("Location: administracion.php");
			 exit;
	       break;
		   case "profesor";
			 header ("Location: adm_notas.php");
		     exit;
		   break;
	}
	}
	
?>