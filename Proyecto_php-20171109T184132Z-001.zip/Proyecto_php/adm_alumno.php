<?php 
header('Location:administracion.php');
exit;
?>