<td width="25%" height="100" background="Imagenes/background.jpg" valign="top">
<ul>
  <?php
  
   if($_SESSION['nivel']=='administrador' ){
	?>
   <li><a href="adm_alumno.php">Alumnos</a></li>
   <li><a href="adm_materia.php">Materias</a></li>
   <li><a href="adm_profesor.php">Profesor</a></li>
   <li><a href="adm_notas.php">Notas</a></li>
   
  <?php
  }
  else
  {
     if($_SESSION['nivel']=='profesor')
	 {
   ?>
   <li><a href="adm_notas.php">Notas</a></li>
   <?php 
   }
   }?>
   
   <li><a href="salir.php">Salir</a></li>
   </ul>
</td>