<?php 
include('encabezado.php');
?>

<br />
<br />
<br />
<br />
<br />
<br />
<form name="form_acceso" action="verificar_usuario.php" method="post">
<table width="100%" background="Imagenes/background.jpg" align="center" border="1" bordercolor="#CCCCCC" cellpadding="0" cellspacing="0" height="100%">
  <tr>
    <td>
	 <font color="#0033FF"><h>Proyecto php</h></font> </td>
  
  </tr>
  <tr>
    <form> 
    <table width="35%" background="Imagenes/background.jpg" bordercolor="#CCCCCC" height="200" align="center" cellspacing="0" cellpadding="0" border="0">

   <?php
   if(isset($_GET['error']))
   {
   ?>
	<tr>
	   <td colspan="2" align="center"><font color="#FF0000"><img src="Imagenes/aero_unavail_xl.cur" width="20" height="20" />&nbsp;<b>
	   <?php
	   switch($_GET['error'])
	   {
	   case 1: echo 'Usuario inv&aacute;lido';
	   break;
	   case 2: echo 'Clave inv&aacute;lida';
	   break;
	   case 3: echo 'Usuario no encontrado';
	   }
	  ?> 
	   </b></font></td>
    </tr>
	<?php
	}
	?>

   <tr>
   <td height="60" colspan="2" align="center" background=""><b>Acceso</b></td>
   </tr>
       <td width="28%" height="57" align="right"><b>Login: </b></td>
	   <td width="72%"><input type="text" value="" name="usuario" size="30"></td>
   </tr>
   <tr>
       <td height="46" align="right"><b>Clave: </b></td>
	   <td><input type="password" value="" name="clave" size="30"></td>
   </tr>
   <tr>
     <td height="35" colspan="2" align="center"><input type="submit" value="Enter" name="entrar">&nbsp;<input type="reset" value="Cancel" name="limpiar"></td>
  </tr>
	   
	   
   
</table>
    </form>
  </tr>



<?php
include('Fin_encabezado.php');
?>