<?php session_start(); ?>
<?php include('encabezado.php');?>
<?php include('base_datos/abrir_conexion_mysql.php');?>

<?php 
if(isset($_POST['guardar']))
{
  if($_POST['codigo']=="" || $_POST['nombre']=="")
  {
     echo "asegurese de llenar los campos obligatorios";
  }
  else
  {
    $cant=0;
    $sql="SELECT Codigo from materia where Codigo='".$_POST['codigo']."'";
	$resultado = mysql_query($sql,$conexion) or die (mysql_error());
	$cant = mysql_num_rows($resultado);
	if($cant > 0)
	    echo "Existe una materia con ese codigo";
	 else
	 {
	   echo $sql="insert into materia (Codigo,Nombre,Descripcion,Cedula) values ('".$_POST['codigo']."','".$_POST['nombre']."','".$_POST['descripcion']."','".$_POST['profesor']."')";
	   $resultado = mysql_query($sql,$conexion) or die (mysql_error());
	   if($resultado==true)
	   {
	   echo 'Registro exitoso';
	   echo "<script languaje='javascript'>location.href='adm_materia.php'</script>";
	   } 
	   else
	   echo 'Error al insertar datos';
	 }
  } 
}
?>

<table width="100%" height="100%" background="Imagenes/background.jpg" align="center" border="1" bordercolor="#CCCCCC" cellpadding="0" cellspacing="0" >

    <?php include('banner.php');?>
  <tr>
    <?php include('menu.php'); ?>
    <td  valign="top" height="150" >
	<form name="form_materia" action="" method="post" enctype="application/x-www-form-urlencoded">
	  <table width="95%" align="center" border="0" cellpadding="0" cellspacing="0">
	  <tr>
	    <td>C&oacute;digo</td>
		<td><input type="text" name="codigo" value="" size="30" maxlength="10"/>*</td>
	  </tr>
	   <tr>
	    <td>Nombre:</td>
		<td><input type="text" name="nombre" value="" size="30"/>*</td>
	  </tr>
	  <tr>
	    <td>Descripci&oacute;n:</td>
		<td><textarea name="descripcion" rows="5" cols="15" ></textarea></td>
	  </tr>
	  <tr>
	    <td>Profesor:</td>
		<td>
		
		<select name="profesor">
		 <option value="">Seleccione</option>
		 <?php
		 
		 $sql_prof="select Cedula,Nombre,Apellido from persona where Tipo='profesor' order by Nombre,Apellido" ;
		 $resultato_prof= mysql_query($sql_prof,$conexion) or die (mysql_error());
		 while($prof = mysql_fetch_array($resultato_prof))
		 {
		 
		 ?>
		 <option value="<?php echo $prof['Cedula']?>"><?php echo $prof['Nombre'].' '.$prof['Apellido']?></option>
		 <?php
		 }
		 ?>
	    </select>
		</td>
	  </tr>
	   <tr>
	    <td>
		<input type="submit" name="guardar" value="Guardar" />&nbsp;&nbsp;&nbsp;
		<input type="reset" name="limpiar" value="Limpiar" />
		
		</td>
	  </tr>
	  <tr>
	    <td>
		<a href="adm_materia.php">Volver</a>
		
		</td>
	  </tr>
	  
	</table>
  </form>
	</td>
	  
  </tr>
  <?php include('pie_pagina.php');?>
</table>
 <?php include('Fin_encabezado.php');?>