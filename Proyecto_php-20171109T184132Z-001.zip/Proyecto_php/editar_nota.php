<?php include('encabezado.php');?>
<?php include('base_datos/abrir_conexion_mysql.php');?>

<?php
if(isset($_GET['id']) && isset($_GET['id2']))
{
   $sql= "SELECT pm.*,p.nombre as nombrep,p.apellido,m.nombre as nombrem FROM persona_materia pm INNER JOIN persona p USING (Cedula) INNER JOIN materia m USING (Codigo) WHERE pm.codigo='".$_GET['id']."' AND pm.Cedula = '".$_GET['id2']."'";
   $resultado= mysql_query($sql,$conexion) or die (mysql_error());
   $filas=mysql_fetch_array($resultado);
  
   $const_id=$filas['Codigo']; 
   $const_id2=$filas['Cedula']; 
   $aux_materia = $filas['nombrem'];
   $aux_alumno = $filas['nombrep'].' '.$filas['apellido'];
   $aux_nota = $filas['Nota'];  
}

if(isset($_POST['guardar']))
{
	if($_POST['nota']=="") 
	{
 		echo'Asegurese de llenar todos los campos obligatorios'; 
	}
	else 
	{
			$sql= "UPDATE persona_materia SET
			nota ='".$_POST['nota']."' 
			WHERE codigo='".$const_id."' AND Cedula='".$const_id2."' "; 
			$resultado = mysql_query($sql,$conexion) or die (mysql_error());
			if($resultado==true)
			{
				echo 'Registro modificado satisfactoriamente';
			?>
					<script language="javascript">location.href='adm_notas.php'</script>
			<?php		
			}
	}
}
if(isset($_POST['nota'])) $aux_nota = $_POST['nota'];
?>



<table width="100%" align="center" border="1" bordercolor="#CCCCCC" background="Imagenes/background.jpg" cellpadding="0" cellspacing="0" height="100%">

    <?php include('banner.php');?>
  <tr>
    <?php include('menu.php'); ?>
    <td  valign="top" height="150" >
	<form name="form_nota" action="" method="post" enctype="application/x-www-form-urlencoded">
	  <table width="95%" align="center" border="0" cellpadding="0" cellspacing="0">
	  <tr>
	    <td width="15%">Alumno:</td>
		<td width="85%">
			<input name="alumno" value="<?php echo $aux_alumno?>" disabled="disabled" />
		*</td>
	  </tr>
	   <tr>
	    <td>Materia:</td>
		<td>
			<input name="materia" value="<?php echo $aux_materia?>" disabled="disabled" />
		*</td>
	  </tr>
	  <tr>
	    <td>Nota:</td>
		<td><input type="text" name="nota" size="5" value="<?php echo $aux_nota?>"></td>
	  </tr>
	  <tr>
	    <td colspan="2" align="center">
		<input type="submit" name="guardar" value="Listo" />&nbsp;&nbsp;&nbsp;
		<input type="reset" name="limpiar" value="Borrar" />
		</td>
	  </tr>
	</table>
  </form>
	</td>
	  
  </tr>
  <?php include('pie_pagina.php');?>
</table>
 <?php include('Fin_encabezado.php');?>