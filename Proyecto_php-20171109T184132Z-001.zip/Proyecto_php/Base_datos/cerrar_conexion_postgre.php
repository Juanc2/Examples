<?php
pg_close($conexion);
?>