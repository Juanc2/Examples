<?php 
$host='localhost';
$usuario='root';
$clave='1236245213';
$nombre_bd='Curso_php';
$conexion=mysql_connect($host,$usuario,$clave) or die (mysql_error());
mysql_select_db($nombre_bd,$conexion);

?>