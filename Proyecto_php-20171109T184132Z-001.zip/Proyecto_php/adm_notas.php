<?php session_start(); ?>
<?php include('encabezado.php');?>



<table width="100%" align="center" border="1" height="100%" bordercolor="#CCCCCC" cellpadding="0" cellspacing="0" height="400" background="Imagenes/background.jpg">

    <?php include('banner.php');?>
  <tr>
    <?php include('menu.php'); ?>
    <td  valign="top" height="150" >
	<br />
    <br />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	  <?php if($_SESSION['nivel']=='profesor'){?>
	   <a href="agregar_nota.php">Agregar</a>
	   <?php } ?>
	   <table width="95%" border="1" cellpadding="0" cellspacing="0" >
	    
	     <tr>
		 <?php if($_SESSION['nivel']=='profesor'){ ?>
		   <th align="center">editar/borrar</th>
		   <?php } ?>
		   <th>cedula</th>
		   <th>nombre</th>
		   <th>C&oacute;digo</th>
		   <th>materia</th>
		   <th>nota</th>
		 </tr>
		 <?php
		 include("base_datos/abrir_conexion_mysql.php");
		 $sql= "SELECT pm. *, p.Nombre as nombrep,p.Apellido,m.Nombre as nombrem FROM persona_materia pm inner join persona p using (Cedula) inner join materia m using (Codigo) order by Cedula asc";
		 $resultado = mysql_query($sql,$conexion) or die (mysql_error());
		 while($filas = mysql_fetch_array($resultado))
		 {
		 ?>
		 <tr>
		 <?php if($_SESSION['nivel']=='profesor'){ ?>
		   <td align="center">
		   <a href="editar_nota.php?id=<?php echo $filas['Codigo']?>&id2=<?php echo $filas['Cedula']?>"><img src="Imagenes/editar.png" width="17" height="17" title="editar" /></a>&nbsp; <a href="eliminar_nota.php?id=<?php echo $filas['Codigo']?>&id2=<?php echo $filas['Cedula']?>"><img src="Imagenes/borrar.png" width="17" height="17" title="borrar" /></a>
		   
		   </td>
		   <?php } ?>
		   <td align="center"><?php echo $filas['Cedula'] ?></td>
		   <td align="center"><?php echo $filas['nombrep'] ?></td>
		   <td align="center"><?php echo $filas['Codigo'] ?></td>
		   <td align="center"><?php echo $filas['nombrem'] ?></td>
		   <td align="center"><?php echo $filas['Nota'] ?></td>
		  </tr>
		  <?php
		  }
		  ?>
		  </table>
	</td>
	  
  </tr>
  <?php include('pie_pagina.php');?>
</table>
 <?php include('Fin_encabezado.php');?>