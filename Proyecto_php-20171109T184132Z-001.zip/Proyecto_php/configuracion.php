<?php session_start(); ?>
<?php include('encabezado.php');?>
<?php include('Base_datos/abrir_conexion_postgre.php');?>

<?php

    $sql="select * from persona inner join usuario using (cedula) where login='".$_SESSION['user_login']."'";
    $resultado= pg_query($conexion,$sql) or die (pg_last_error());
    $filas=pg_fetch_array($resultado);
   
    $aux_ci = $filas['cedula'];
    $aux_nombre = $filas['nombre'];
    $aux_apellido = $filas['apellido'];
    $aux_sexo = $filas['sexo'];
    $aux_direccion = $filas['direccion'];
    $aux_login = $_SESSION['user_login'];
if(isset($_POST['guardar']))
{

if($_POST['login']==$_SESSION['user_login'])
	{
		$sql = "UPDATE persona SET 
			nombre = '".$_POST['nombre']."',
			apellido = '".$_POST['apellido']."',
			sexo= '".$_POST['sexo']."',
			direccion = '".$_POST['direccion']."'
			WHERE cedula = '".$const_id."'";
			
		$result = pg_query($conexion,$sql) or die (pg_last_error());
		if($result==true)
		{
			echo 'Registro modificado satisfactoriamente';
		?>
				<script language="javascript">location.href='administracion.php'</script>
<?php		
		}
	}
	else
	{
		$sql="SELECT Login FROM usuario WHERE Login='".$_POST['login']."'";
		$resultado = mysql_query($sql,$conexion) or die (mysql_error());
		$cant = mysql_num_rows($resultado);
		if($cant > 0)
			echo "Existe una persona con esa cedula";
		else
		{
			$sql = "UPDATE persona SET 
			cedula = '".$_POST['cedula']."',
			nombre = '".$_POST['nombre']."',
			apellido = '".$_POST['apellido']."',
			sexo= '".$_POST['sexo']."',
			direccion = '".$_POST['direccion']."'
			WHERE cedula = '".$_POST['const_id']."'";
			
			$result = pg_query($conexiion,$sql) or die(pg_last_error());
			
			$sql2 = "update persona set
			login = '".$_SESSION['login']."'
			where login = '".$_SESSION['user_login']."'";
			
			$result2 = pg_query($conexion,$sql2) or die (pg_last_error());
	
			if($result==true && $result2==true)
			{
				echo 'Registro modificado satisfactoriamente';
				?>
				<script language="javascript">location.href='administracion.php'</script>
<?php	
			}
		}
	}

}

if(isset($_POST['cedula'])) $aux_ci = $_POST['cedula'];
if(isset($_POST['nombre'])) $aux_nombre = $_POST['nombre'];
if(isset($_POST['apellido'])) $aux_apellido = $_POST['apellido'];
if(isset($_POST['sexo'])) $aux_sexo = $_POST['sexo'];
if(isset($_POST['direccion'])) $aux_direccion = $_POST['direccion'];

?>



<table width="100%" align="center" border="1" background="Imagenes/background.jpg" bordercolor="#CCCCCC" cellpadding="0" cellspacing="0" height="100%">

    <?php include('banner.php');?>
  <tr>
    <?php include('menu.php'); ?>
    <td  valign="top" height="150" >
	<form name="form_alumno" action="" method="post" enctype="application/x-www-form-urlencoded">
	<input type="hidden" name="const_id" value="<?php echo $aux_ci ?>" />
	  <table width="95%" align="center" border="0" cellpadding="0" cellspacing="0">
	  <tr>
	    <td>C&eacute;dula:</td>
		<td><input type="text" name="cedula" value="<?php echo $aux_ci ?>" size="30"/>*</td>
	  </tr>
	   <tr>
	    <td>Nombre:</td>
		<td><input type="text" name="nombre" value="<?php echo $aux_nombre ?>" size="30"/>*</td>
	  </tr>
	   <tr>
	    <td>Apellido:</td>
		<td><input type="text" name="apellido" value="<?php echo $aux_apellido ?>" size="30"/>*</td>
	  </tr>
	   <tr>
	    <td>Sexo:</td>
	    <td>
		 M<input type="radio" name="sexo" value="M" <?php if($aux_sexo=='M') echo 'checked="checked"'; ?> />
		 F<input type="radio" name="sexo" value="F" <?php if($aux_sexo=='F') echo 'checked="checked"'; ?>/>*
		</td>
	  </tr>
	  <tr>
	    <td>Direcc&iacute;on:</td>
		<td><textarea name="direccion" rows="5" cols="15" ><?php echo $aux_direccion ?></textarea></td>
	  </tr>
	  <tr>
	    <td>Login:</td>
		<td><input type="text" name="Login" <?php echo $aux_login ?>size="30" /></td>
	  </tr> 
	  <tr>
	    <td>
		<input type="submit" name="guardar" value="Listo" />&nbsp;&nbsp;&nbsp;
		<input type="reset" name="limpiar" value="Borrar" />
		
		</td>
	  </tr>
	  <tr>
	    <td>
		<a href="administracion.php">Volver</a>
		
		</td>
	  </tr>
	  
	</table>
  </form>
	</td>
	  
  </tr>
  <?php include('pie_pagina.php');?>
</table>
 <?php include('Fin_encabezado.php');?>