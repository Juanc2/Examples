<?php session_start(); ?>
<?php include('encabezado.php');?>
 
<table width="100%" align="center" height="100%" border="1" bordercolor="#CCCCCC" cellpadding="0" cellspacing="0" background="Imagenes/background.jpg">

    <?php include('banner.php');?>
  <tr>
    <?php include('menu.php'); ?>
    <td  valign="top" height="150" >
	<br />
    <br />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
       <a href="agregar_alumno.php">Agregar alumno</a>
	 
	   <table width="95%" border="1" cellpadding="0" cellspacing="0" >
	    
	     <tr>
		   <th>editar / borrar</th>
		   <th>C&eacute;dula</th>
		   <th>Nombre</th>
		   <th>Apellido</th>
		   <th>Sexo</th>
		   <th>Direcc&iacute;on</th>
		 </tr>
		 <?php
		 include("base_datos/abrir_conexion_mysql.php");
		 $sql= "SELECT * FROM persona WHERE tipo='alumno' ORDER BY Cedula ASC";
		 $resultado = mysql_query($sql,$conexion) or die (mysql_error());
		 while($filas = mysql_fetch_array($resultado))
		 {
		 ?>
		 <tr>
		   <td align="center"><a href="editar_alumno.php?id=<?php echo $filas['Cedula']?>"><img src="Imagenes/editar.png" width="17" height="17" title="editar" /></a>&nbsp; <a href="eliminar_alumno.php?id=<?php echo $filas['Cedula']?>"><img src="Imagenes/borrar.png" width="17" height="17" title="borrar" /></a>  
		   </td>
		   <td align="center"><?php echo $filas['Cedula'] ?></td>
		   <td align="center"><?php echo $filas['Nombre'] ?></td>
		   <td align="center"><?php echo $filas['Apellido'] ?></td>
		   <td align="center"><?php echo $filas['Sexo'] ?></td>
		   <td align="center"><?php echo $filas['Direccion'] ?></td>
		  </tr>
		  <?php
		  }
		  ?>
		  </table>
	</td>
	  
  </tr>
  <?php include('pie_pagina.php');?>
</table>
 <?php include('Fin_encabezado.php');?>