<?php session_start(); ?>
<?php include('encabezado.php');?>
<?php include('base_datos/abrir_conexion_mysql.php');?>

<?php 
if(isset($_POST['guardar']))
{
  if($_POST['cedula']=="" || $_POST['nombre']=="" || $_POST['apellido']=="" || $_POST['sexo']=="")
  {
     echo "asegurese de llenar los campos obligatorios";
  }
  else
  {
    $cant=0;
    $sql="SELECT Cedula from persona where Cedula='".$_POST['cedula']."'";
	$resultado = mysql_query($sql,$conexion) or die (mysql_error());
	$cant = mysql_num_rows($resultado);
	  if($cant > 0)
	    echo "Existe una persona con ese numero de cedula";
	 else
	 {
	   $sql="insert into persona (Cedula,Nombre,Apellido,Sexo,Direccion,Tipo) values ('".$_POST['cedula']."','".$_POST['nombre']."','".$_POST['apellido']."','".$_POST['sexo']."','".$_POST['direccion']."','profesor')";
	   $resultado = mysql_query($sql,$conexion) or die (mysql_error());
	   if($resultado==true)
	   {
	   echo 'Registro exitoso';
	   echo "<script languaje='javascript'>location.href='adm_profesor.php'</script>";
	   } 
	   else
	   echo 'Error al insertar datos';
	 }
  } 
 }
?>

<table width="100%" background="Imagenes/background.jpg" align="center" border="1" bordercolor="#CCCCCC" cellpadding="0" cellspacing="0" height="100%">

    <?php include('banner.php');?>
  <tr>
    <?php include('menu.php'); ?>
    <td  valign="top" height="150" >
	<form name="form_alumno" action="" method="post" enctype="application/x-www-form-urlencoded">
	  <table width="95%" align="center" border="0" cellpadding="0" cellspacing="0">
	  <tr>
	    <td>C&eacute;dula:</td>
		<td><input type="text" name="cedula" value="" size="30"/>*</td>
	  </tr>
	   <tr>
	    <td>Nombre:</td>
		<td><input type="text" name="nombre" value="" size="30"/>*</td>
	  </tr>
	   <tr>
	    <td>Apellido:</td>
		<td><input type="text" name="apellido" value="" size="30"/>*</td>
	  </tr>
	   <tr>
	    <td>Sexo:</td>
	    <td>
		 M<input type="radio" name="sexo" value="M" />
		 F<input type="radio" name="sexo" value="F" />*
		</td>
	  </tr>
	  <tr>
	    <td>Direcc&iacute;on:</td>
		<td><textarea name="direccion" rows="5" cols="15" ></textarea></td>
	  </tr>
	  <tr>
	    <td>
		<input type="submit" name="guardar" value="Guardar" />&nbsp;&nbsp;&nbsp;
		<input type="reset" name="limpiar" value="Borrar" />
		
		</td>
	  </tr>
	  <tr>
	    <td>
		<a href="adm_profesor.php">Volver</a>
		
		</td>
	  </tr>
	  
	</table>
  </form>
	</td>
	  
  </tr>
  <?php include('pie_pagina.php');?>
</table>
 <?php include('Fin_encabezado.php');?>