<tr>
    <td colspan="2" height="100" background="Imagenes/background.jpg" width="100" align="center"><b>&nbsp; Proyecto php</b></td>
	<td><a href="configuracion.php">Configuracion</a></td>
  </tr>