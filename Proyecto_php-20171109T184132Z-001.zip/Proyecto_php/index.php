<?php
header('Location:acceso.php');
exit;
?>