 <tr>
   <td colspan="2" background="Imagenes/background.jpg" width="100%" height="150" align="center"><b>Pie de pagina</b></td>
  </tr>