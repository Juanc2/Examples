<? include('encabezado.php');?>
<table width="100%" align="center" height="300" border="1" bordercolor="#0000FF" cellpadding="0" cellspacing="0">
  
  <tr>
   <td>Menu</td>
   <td>Contenido</td>
  </tr>
  <tr>
   <td colspan="2">Pie de pagina</td>
  </tr>
</table>
<?php include('Fin_encabezado.php');?>